from geofirex.compact_calibration import main
if __name__ == '__main__': main()
